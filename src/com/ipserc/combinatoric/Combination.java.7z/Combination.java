package com.ipserc.combinatoric;

import java.util.List;
import java.util.*;

public class Combination {
	
	public int factorial(int num) {
		int factorial;
		if (num == 0) return 1;
		else factorial = num * factorial(--num);
		return factorial;
	}
	
	public int numberOf(int grade, int order) {
		return factorial(grade)/factorial(order)/factorial(grade-order);
	}
	
	public int[]initialize(int[] v) {
		for (int i = 0; i < v.length; ++i) v[i] = -1;
		return v;
	}

/****************
 * Item Methods *
 ****************/
	
	public int[] getItem(int grade, int order, int itemNbr) {
		int i, j; 
		int item = 0;
		int[] v = new int[grade];

		int numOfItems = numberOf(grade, order);
		
		if (itemNbr + 1 > numOfItems) return v; 

		if (order == 0) return v;

		for(i = 0; i < grade; ++i) v[i]=i;
		if (itemNbr == 0) return v;
		
		while (true) {
			i = order-1;
		    while (v[i] == grade-order+i && --i >= 0);
		    if (i < 0) break;
		    v[i] += 1;
		    for (j = i+1; j < order; ++j) v[j] = v[i]+j-i;
		    if (++item == itemNbr) break;
		}
		return v;
	}
	
	public String toStringItem(int[] v, int order) {
		String combine = "";
		int i;
		if (order == 0) return "NULL";
		for(i = 0; i < order-1; ++i) combine = combine + v[i] + ",";
		combine = combine + v[i];
		return combine;
	}

	public void printlnItem(int[] v, int order) {
		System.out.println(toStringItem(v, order));
	}
	
/**********************
 * Collection Methods *
 **********************/
	
	public int[] itemColl(int[] itemColl, int[] v, int order) {
		for(int i = 0; i < order; ++i) itemColl[i] = v[i];
		return itemColl;
	}
	
	public int[][] getCollection(int grade, int order) {
		int i, j; 
		int itemNbr = 0;
		int numOfItems = numberOf(grade, order);
		int[] v = new int[grade];
		int[][] collection = new int[numOfItems][order];
		
		if (order == 0) return collection;

		for(i = 0; i < grade; ++i) v[i]=i;
	    collection[itemNbr] = itemColl(collection[itemNbr], v, order);
	    ++itemNbr;
		while (true) {
			i = order-1;
		    while (v[i] == grade-order+i && --i >= 0);
		    if (i < 0) break;
		    v[i] += 1;
		    for (j = i+1; j < order; ++j) v[j] = v[i]+j-i;
		    collection[itemNbr] = itemColl(collection[itemNbr], v, order);
		    if (++itemNbr == numOfItems) break;
		}
		return collection;
	}
	
	public String[] toStringCollection(int[][] collection) {
		String[] strColl = new String[collection.length];
		for (int item = 0; item < collection.length; ++item) {
			strColl[item] = toStringItem(collection[item], collection[item].length);
		}
		return strColl;
	}
	
	public void printlnCollection(int[][] collection) {
		for (int itemNbr = 0; itemNbr < collection.length; ++itemNbr) {
			System.out.print("itemNbr:" + itemNbr + " - ");
			printlnItem(collection[itemNbr], collection[itemNbr].length);
		}
	}
	
/****************************
 * All Combinations Methods *
 ****************************/
	
	public List<int[][]> getAll(int grade) {
		List<int[][]> allCombinations = new ArrayList<>();
		for (int order = 0; order <= grade; ++order) {		
			allCombinations.add(getCollection(grade, order));
		}
		return allCombinations;
	}
	
	public String[][] toStringAll(List<int[][]> allCombinations) {
		String[][] strAllCombi = new String[allCombinations.size()][];
		for (int listItem = 0; listItem < allCombinations.size(); ++listItem) {
			strAllCombi[listItem] = toStringCollection((int[][])allCombinations.get(listItem));
		}
		return strAllCombi;
	}
	
	public void printlAll(List<int[][]> allCombinations) {
		for (int order = 0; order < allCombinations.size(); ++order) {
			System.out.print("order:" + order + "\n");			
			printlnCollection((int[][])allCombinations.get(order));
		}
		
	}
	
	public void printAll_(int grade, int order) {
		int i, j;
		int[] v = new int[grade];
		
		if (order == 0) return;

		for(i = 0; i < grade; ++i) v[i]=i;
		printlnItem(v, order);
		
		while (true) {
			i = order-1;
		    while (v[i] == grade-order+i && --i >= 0);
		    if (i < 0) break;
		    v[i] += 1;
		    for (j = i+1; j < order; ++j) v[j] = v[i]+j-i;
		    printlnItem(v, order);
		}
	}


}