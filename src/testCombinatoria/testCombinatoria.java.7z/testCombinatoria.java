package testCombinatoria;
import java.util.List;

import com.ipserc.combinatoric.Combination;

public class testCombinatoria {
	
	public static void oldTest() {
		int grade = 4;
		int order;
		int item;
		Combination combinat = new Combination();
		for (order = 0; order <= grade; ++order) {
			System.out.println("Grade:" + grade + " - Order:" + order);
			System.out.println("There is a total of "+combinat.numberOf(grade, order)+" combinations without repetitions.");
			combinat.printAll_(grade, order);
			System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		}
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		order = 4;
		combinat.printAll_(grade, order);
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		for (item = 0; item < 20; ++item) {		
			System.out.println("Grade:" + grade + " - Order:" + order + " - Item:" + item + " - " + combinat.toStringItem(combinat.getItem(grade, order, item), order));
			System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		}
		
	}

	public static void main(String[] args) {
		int grade = 10;
		int order = 5;
		int itemNbr = 6;
		Combination combinat = new Combination();
		
		//testCombinatoria.oldTest();
		
		/*********************************/
		/* Test All Combinations Methods */
		/*********************************/
		List<int[][]> allComblist;
		allComblist = combinat.getAll(grade);
		combinat.printlAll(allComblist);
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");

		/***************************/
		/* Test Collection Methods */
		/***************************/
		int[][] collection;
		collection = combinat.getCollection(grade, order);
		System.out.println("Grade:" + grade + " - Order:" + order);
		combinat.printlnCollection(collection);
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");

		/*********************/
		/* Test Item Methods */
		/*********************/
		int[] item;
		item = combinat.getItem(grade, order, itemNbr);
		System.out.println("Grade:" + grade + " - Order:" + order + " - ItemNbr:" + itemNbr); 
		combinat.printlnItem(item, order);
		System.out.println("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-");
		
	}
}

